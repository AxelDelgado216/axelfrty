
AXEL STORE — Tienda estática con carrito + WhatsApp
Última actualización: 2025-08-24 03:56 UTC

1) Editá config.js:
   - whatsapp: tu número con código país (ej: +5989XXXXXXX)
   - instagram: tu URL de IG
   - currency: "UYU"

2) Editá products.json para cambiar productos, precios y talles.
   - "img": poné tu propia foto en /assets y usa ese nombre.
   - Para agregar productos, copiá un objeto y cambia id único (p10, p11...).

3) Publicar (GitHub Pages):
   - Creá repo (público), subí todos los archivos.
   - Settings → Pages → Deploy from a branch (main, /root).
   - Tu URL será https://TU-USUARIO.github.io/NOMBRE-REPO/

   Alternativa: Netlify o Vercel (arrastrar carpeta y deploy).

4) Cómo funciona el checkout:
   - Los clientes agregan productos, eligen talle/color y completan el formulario.
   - Se abre WhatsApp con el pedido (items + total + datos) para coordinar pago/envío.

5) Personalización visual:
   - Cambiá colores en :root de style.css (brand/brand2).
   - Reemplazá assets/hero.png por tu banner.
