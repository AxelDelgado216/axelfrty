
// Configura tus enlaces de contacto
window.STORE_CONFIG = {
  whatsapp: "+59800000000", // <-- CAMBIA a tu número con prefijo país (p. ej. +5989xxxxxxx)
  instagram: "https://instagram.com/tu_usuario", // <-- CAMBIA tu IG
  currency: "UYU"
};
