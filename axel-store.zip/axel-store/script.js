
let PRODUCTS = [];
const state = {
  cart: JSON.parse(localStorage.getItem('cart') || '[]'),
  filters: { q:'', tag:'', sort:'featured' }
};

// DOM refs
const grid = document.getElementById('grid');
const search = document.getElementById('search');
const filterTag = document.getElementById('filterTag');
const sortBy = document.getElementById('sortBy');
const cartBtn = document.getElementById('cartBtn');
const cart = document.getElementById('cart');
const backdrop = document.getElementById('backdrop');
const closeCart = document.getElementById('closeCart');
const cartItems = document.getElementById('cartItems');
const subtotalEl = document.getElementById('subtotal');
const cartCount = document.getElementById('cartCount');
const menuBtn = document.getElementById('menuBtn');
const menu = document.getElementById('menu');
const modeBtn = document.getElementById('modeBtn');
const waDirect = document.getElementById('waDirect');
const igLink = document.getElementById('igLink');
const year = document.getElementById('year');
const orderForm = document.getElementById('orderForm');
const cfg = window.STORE_CONFIG || {};

year.textContent = new Date().getFullYear();
waDirect.href = `https://wa.me/${cfg.whatsapp.replace(/[^0-9]/g,'')}`;
igLink.href = cfg.instagram || "#";

// Theme
const savedMode = localStorage.getItem('mode');
if(savedMode === 'light'){ document.body.classList.add('light'); }
modeBtn.addEventListener('click', ()=>{
  document.body.classList.toggle('light');
  localStorage.setItem('mode', document.body.classList.contains('light') ? 'light' : 'dark');
});

// Menu
menuBtn.addEventListener('click', ()=> menu.classList.toggle('show'));

// Cart drawer
function openCart(){ cart.classList.add('open'); backdrop.classList.add('show'); }
function closeCartFn(){ cart.classList.remove('open'); backdrop.classList.remove('show'); }
cartBtn.addEventListener('click', openCart);
closeCart.addEventListener('click', closeCartFn);
backdrop.addEventListener('click', closeCartFn);

// Load products
fetch('products.json').then(r=>r.json()).then(data=>{ PRODUCTS = data; render(); renderCart(); });

// Filters
search.addEventListener('input', ()=>{ state.filters.q = search.value.trim().toLowerCase(); render(); });
filterTag.addEventListener('change', ()=>{ state.filters.tag = filterTag.value; render(); });
sortBy.addEventListener('change', ()=>{ state.filters.sort = sortBy.value; render(); });

function render(){
  let items = PRODUCTS.slice();
  const {q,tag,sort} = state.filters;
  if(q){ items = items.filter(p=> (p.title.toLowerCase().includes(q))); }
  if(tag){ items = items.filter(p=> p.tag === tag); }
  if(sort==='price-asc'){ items.sort((a,b)=>a.price-b.price); }
  if(sort==='price-desc'){ items.sort((a,b)=>b.price-a.price); }
  if(sort==='title-asc'){ items.sort((a,b)=> a.title.localeCompare(b.title, 'es')); }
  grid.innerHTML = items.map(cardHTML).join('');
  attachCardEvents();
}

function money(n){ return (cfg.currency || 'UYU') + ' ' + n.toLocaleString('es-UY'); }

function cardHTML(p){
  const sizePills = p.sizes.map(s=>`<span class="pill" data-type="size">${s}</span>`).join('');
  const colorPills = (p.colors||[]).map(c=>`<span class="pill" data-type="color">${c}</span>`).join('');
  return `
  <article class="card" data-id="${p.id}">
    <img src="${p.img}" alt="${p.title}" loading="lazy">
    <h3>${p.title}</h3>
    <p class="price">${money(p.price)}</p>
    <div class="pills" data-role="sizes">${sizePills}</div>
    <div class="pills" data-role="colors">${colorPills}</div>
    <div class="row add">
      <button class="btn primary" data-action="add">Agregar</button>
      <button class="btn ghost" data-action="wish">❤️</button>
    </div>
  </article>`;
}

function attachCardEvents(){
  document.querySelectorAll('.card').forEach(card=>{
    let size='', color='';
    card.querySelectorAll('.pill').forEach(pill=>{
      pill.addEventListener('click', ()=>{
        const type = pill.dataset.type;
        (pill.parentElement.querySelectorAll('.pill')||[]).forEach(el=>el.classList.remove('active'));
        pill.classList.add('active');
        if(type==='size') size = pill.textContent;
        if(type==='color') color = pill.textContent;
      });
    });
    card.querySelector('[data-action="add"]').addEventListener('click', ()=>{
      const id = card.dataset.id;
      const prod = PRODUCTS.find(x=>x.id===id);
      const item = { id, title: prod.title, price: prod.price, size: size || prod.sizes[0], color: color || (prod.colors?prod.colors[0]:''), img: prod.img, qty: 1 };
      // merge
      const existing = state.cart.find(x=> x.id===id && x.size===item.size && x.color===item.color);
      if(existing){ existing.qty += 1; } else { state.cart.push(item); }
      saveCart(); renderCart(); openCart();
    });
  });
}

function renderCart(){
  cartItems.innerHTML = state.cart.map((it, i)=>`
    <div class="cart-item" data-i="${i}">
      <img src="${it.img}" alt="${it.title}">
      <div>
        <div><strong>${it.title}</strong></div>
        <div>${it.size} ${it.color? '• '+it.color: ''}</div>
        <div>${money(it.price)} x 
          <button data-action="minus">-</button>
          <span>${it.qty}</span>
          <button data-action="plus">+</button>
        </div>
      </div>
      <button data-action="remove">✕</button>
    </div>
  `).join('');
  const subtotal = state.cart.reduce((s,it)=> s + it.price*it.qty, 0);
  subtotalEl.textContent = money(subtotal);
  cartCount.textContent = state.cart.reduce((s,it)=> s + it.qty, 0);

  cartItems.querySelectorAll('.cart-item').forEach(row=>{
    const i = +row.dataset.i;
    row.querySelector('[data-action="remove"]').addEventListener('click', ()=>{ state.cart.splice(i,1); saveCart(); renderCart(); });
    row.querySelector('[data-action="plus"]').addEventListener('click', ()=>{ state.cart[i].qty++; saveCart(); renderCart(); });
    row.querySelector('[data-action="minus"]').addEventListener('click', ()=>{ state.cart[i].qty = Math.max(1, state.cart[i].qty-1); saveCart(); renderCart(); });
  });
}

function saveCart(){ localStorage.setItem('cart', JSON.stringify(state.cart)); }

// Checkout
document.getElementById('checkoutBtn').addEventListener('click', ()=>{
  document.getElementById('contacto').scrollIntoView({behavior:'smooth'});
  closeCartFn();
});

orderForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  if(!state.cart.length){ alert('Tu carrito está vacío.'); return; }
  const name = document.getElementById('name').value.trim();
  const city = document.getElementById('city').value.trim();
  const notes = document.getElementById('notes').value.trim();
  const lines = state.cart.map(it=> `• ${it.title} (${it.size}${it.color? ', '+it.color:''}) x${it.qty} — ${money(it.price*it.qty)}`);
  const total = state.cart.reduce((s,it)=> s + it.price*it.qty, 0);
  const text = [
    `Hola! Soy ${name}. Quiero hacer este pedido:`,
    ...lines,
    `Total: ${money(total)}`,
    `Zona: ${city}`,
    notes? `Notas: ${notes}` : ''
  ].filter(Boolean).join('\n');
  const phoneDigits = (cfg.whatsapp||'').replace(/[^0-9]/g,'');
  if(!phoneDigits){ alert('Configura tu número de WhatsApp en config.js'); return; }
  const url = `https://wa.me/${phoneDigits}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
});

// Keyboard: open cart with 'c'
window.addEventListener('keydown', (e)=>{ if(e.key.toLowerCase()==='c') openCart(); });
